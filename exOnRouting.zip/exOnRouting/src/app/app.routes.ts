import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { PostsComponent } from './posts/posts.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { BookComponent } from './book/book.component';

export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:"user",component:UserComponent},
    {path:'post',component:PostsComponent},
    {path:'book/:id',component:BookComponent},
    {path:'**',component:PagenotfoundComponent}

];
