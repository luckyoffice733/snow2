import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'exOnRouting';

  
  constructor(private rtObj:Router){}


  pageNavigation(){

    this.rtObj.navigate(['/user'])


  }


}
