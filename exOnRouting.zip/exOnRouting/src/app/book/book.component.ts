import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-book',
  imports: [],
  templateUrl: './book.component.html',
  styleUrl: './book.component.css'
})
export class BookComponent  implements OnInit{

   bookpageNo:string|null=null;

   constructor(private actObj:ActivatedRoute){}



  ngOnInit(): void {
      this.actObj.paramMap.subscribe( rs =>{
      this.bookpageNo=rs.get('id');
      })
  }
}
