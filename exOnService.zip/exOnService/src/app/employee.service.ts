import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

  empData:Employee[]=[
    {'empId':1011,'empName':'smith','empSal':3002},
    {'empId':10212,'empName':'martin','empSal':5232},
    {'empId':10565,'empName':'johndoe','empSal':4232},
  ];

  getEmployeeDetails():any{
    return this.empData;
  }


}
