import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeService } from './employee.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent  implements OnInit{
  title = 'exOnService';
  eData:any[]=[]

//from the service layer use the business logic by creating object for the service class
 constructor(private empService :EmployeeService){//DI(Dependency Injection)
  }


ngOnInit(): void {
  //gettting the data from the EmployeeService
   this.eData=   this.empService.getEmployeeDetails();
}

}
