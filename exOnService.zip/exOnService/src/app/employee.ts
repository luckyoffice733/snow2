export class Employee {
    empId:number;
    empName:string;
    empSal:number;

    constructor(empId:number,empName:string,empSal:number){
     this.empId=empId;
     this.empName=empName;
     this.empSal=empSal;
    }
}
