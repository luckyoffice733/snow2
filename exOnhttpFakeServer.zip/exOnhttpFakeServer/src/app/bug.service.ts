import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BugIssue } from './bug-issue';

@Injectable({
  providedIn: 'root'
})
export class BugService {
    apiUrl="http://localhost:3000/bugtracking";
  constructor(private httpClient:HttpClient) { }

  bugIssueDetails():Observable<any>{
    return this.httpClient.get(this.apiUrl);
  }
}
