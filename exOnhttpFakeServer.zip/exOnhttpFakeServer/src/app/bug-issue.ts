export class BugIssue {

    issue_name:string;
    issue_message:string;
    id:string;

    constructor(issue_name:string,issue_message:string,id:string){
        this.issue_message=issue_message;
        this.issue_name=issue_name;
        this.id=id;
    }

}
