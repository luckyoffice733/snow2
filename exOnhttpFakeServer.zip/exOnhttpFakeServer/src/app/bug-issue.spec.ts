import { BugIssue } from './bug-issue';

describe('BugIssue', () => {
  it('should create an instance', () => {
    expect(new BugIssue()).toBeTruthy();
  });
});
