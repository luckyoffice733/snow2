import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BugService } from './bug.service';
import { BugIssue } from './bug-issue';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'exOnhttpFakeServer';
  bugIssue:any[]=[];
  constructor(private bugService: BugService){}

ngOnInit(): void {
     this.bugService.bugIssueDetails().subscribe(
      (resp) =>this.bugIssue=resp,
    (err)=>{
      console.log("Url is not found")
    })
}
}
