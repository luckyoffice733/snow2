import { Component, OnDestroy, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent  implements OnInit,OnDestroy{
  title = 'exOnLifeCycleMethods';

  constructor(){
    console.log("AppComponent class Object is created/initialization/instancation")
  }

  ngOnInit(): void {
      console.log("we are in ngOnInit lifeccycle method -: this method will we executed"
        +"after the initialztion(object creation)")
  }

  ngOnDestroy(): void {
      console.log("we are in ngOnDestroy lifecycle method: after component object destroy")
  }

}
