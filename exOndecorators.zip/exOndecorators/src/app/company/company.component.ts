import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-company',
  imports: [CommonModule],
  templateUrl: './company.component.html',
  styleUrl: './company.component.css'
})
export class CompanyComponent {

  @Input()  companyName:string|undefined;
   
  @Output()  messageToParent=new EventEmitter<string>();

   
  sendData(){
    this.messageToParent.emit('Hello We are from Child ')
  }


}
