import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BookService } from './book.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'exOnHttpClient';
   booKdata:any[]=[];
   //creating or initialize the object for service class
  constructor(private bookService:BookService){}

  ngOnInit(): void {
      this.bookService.getBookData().subscribe(
        (resp)=>{this.booKdata=resp},
        (errors)=>{
          console.log("url is not found")
        }
      )
  }
}
