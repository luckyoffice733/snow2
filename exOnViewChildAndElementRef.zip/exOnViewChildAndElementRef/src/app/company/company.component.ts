import { Component } from '@angular/core';

@Component({
  selector: 'app-company',
  imports: [],
  templateUrl: './company.component.html',
  styleUrl: './company.component.css'
})
export class CompanyComponent {

   companyName:string="HCL TECH Company";
    


}
