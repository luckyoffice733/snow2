import { Component, ElementRef, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CompanyComponent } from './company/company.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CompanyComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'exOnViewChildAndElementRef';

  @ViewChild(CompanyComponent) cref= new CompanyComponent();
   
  receivedMessageFromChild:string= this.cref.companyName;
  
  @ViewChild('heading') elRef !: ElementRef; //to perform DOM Manuplation

 changeText(){
      this.elRef.nativeElement.innerHTML="Working with ElementRef";
      this.elRef.nativeElement.style.textColor="blue";
 }


}
